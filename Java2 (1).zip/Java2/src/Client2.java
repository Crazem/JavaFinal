import javax.swing.*;

public class Client2 {
    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                ClientFrame frame = new ClientFrame();
                frame.setSize(400, 300);
                frame.setTitle("Trivia Client 2");
                frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                frame.setLocationRelativeTo(null);
                frame.setVisible(true);
            }
        });
    }
}
