import javax.swing.*;
import java.awt.*;
import java.io.*;
import java.net.Socket;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class ClientFrame extends JFrame {

    private CardLayout cardLayout;
    private JPanel mainPanel;

    private JTextField loginUsernameField;
    private JPasswordField loginPasswordField;
    private JButton loginButton;

    private JLabel questionLabel;
    private JButton[] optionButtons = new JButton[4];
    private JLabel feedbackLabel;

    private Socket socket;
    private ObjectOutputStream output;
    private ObjectInputStream input;

    private ExecutorService executor = Executors.newSingleThreadExecutor();

    public ClientFrame() {
        setTitle("Trivia Client");
        setSize(500, 400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        cardLayout = new CardLayout();
        mainPanel = new JPanel(cardLayout);

        createLoginPanel();
        createGamePanel();

        add(mainPanel);
        setVisible(true);
    }

    private void createLoginPanel() {
        JPanel loginPanel = new JPanel(new GridLayout(3, 2, 10, 10));
        loginPanel.setBorder(BorderFactory.createEmptyBorder(50, 50, 50, 50));

        loginPanel.add(new JLabel("Username:"));
        loginUsernameField = new JTextField();
        loginPanel.add(loginUsernameField);

        loginPanel.add(new JLabel("Password:"));
        loginPasswordField = new JPasswordField();
        loginPanel.add(loginPasswordField);

        loginButton = new JButton("Login");
        loginPanel.add(loginButton);

        loginButton.addActionListener(e -> {
            String username = loginUsernameField.getText();
            String password = new String(loginPasswordField.getPassword());
            if (!username.isEmpty() && !password.isEmpty()) {
                connectToServer(username, password);
            } else {
                JOptionPane.showMessageDialog(ClientFrame.this, "Please enter username and password");
            }
        });

        mainPanel.add(loginPanel, "Login");
    }

    private void createGamePanel() {
        JPanel gamePanel = new JPanel(new BorderLayout(10, 10));

        questionLabel = new JLabel("Waiting for question...", SwingConstants.CENTER);
        questionLabel.setFont(new Font("Arial", Font.BOLD, 18));
        gamePanel.add(questionLabel, BorderLayout.NORTH);

        JPanel optionsPanel = new JPanel(new GridLayout(2, 2, 10, 10));
        for (int i = 0; i < 4; i++) {
            int index = i;
            optionButtons[i] = new JButton();
            optionButtons[i].setEnabled(false);
            optionButtons[i].addActionListener(e -> sendAnswer(index));
            optionsPanel.add(optionButtons[i]);
        }
        gamePanel.add(optionsPanel, BorderLayout.CENTER);

        feedbackLabel = new JLabel("", SwingConstants.CENTER);
        feedbackLabel.setFont(new Font("Arial", Font.BOLD, 16));
        gamePanel.add(feedbackLabel, BorderLayout.SOUTH);

        mainPanel.add(gamePanel, "Game");
    }

    private void connectToServer(String username, String password) {
        executor.execute(() -> {
            try {
                socket = new Socket("localhost", 8081);
                output = new ObjectOutputStream(socket.getOutputStream());
                output.flush();
                input = new ObjectInputStream(socket.getInputStream());

                String prompt = (String) input.readObject();
                output.writeObject(username);
                output.flush();

                String passwordPrompt = (String) input.readObject();
                output.writeObject(password);
                output.flush();

                String welcome = (String) input.readObject();
                SwingUtilities.invokeLater(() -> {
                    JOptionPane.showMessageDialog(ClientFrame.this, welcome);
                    cardLayout.show(mainPanel, "Game");
                });

                while (true) {
                    Object obj = input.readObject();
                    if (obj instanceof Question) {
                        Question q = (Question) obj;
                        SwingUtilities.invokeLater(() -> displayQuestion(q));
                    } else if (obj instanceof Integer) {
                        int correctIndex = (Integer) obj;
                        SwingUtilities.invokeLater(() -> highlightCorrectAnswer(correctIndex));
                    } else if (obj instanceof String) {
                        String feedback = (String) obj;
                        SwingUtilities.invokeLater(() -> feedbackLabel.setText(feedback));
                    }
                }

            } catch (EOFException eof) {
                System.out.println("Server closed connection.");
            } catch (Exception e) {
                e.printStackTrace();
                SwingUtilities.invokeLater(() ->
                        JOptionPane.showMessageDialog(ClientFrame.this, "Connection error: " + e.getMessage()));
            }
        });
    }

    private void displayQuestion(Question q) {
        questionLabel.setText(q.getQuestion());
        String[] options = q.getOptions();
        feedbackLabel.setText("");
        for (int i = 0; i < 4; i++) {
            optionButtons[i].setText(options[i]);
            optionButtons[i].setEnabled(true);
            optionButtons[i].setBackground(null);
        }
    }

    private void sendAnswer(int index) {
        try {
            output.writeObject(String.valueOf(index));
            output.flush();
            for (JButton btn : optionButtons) btn.setEnabled(false);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void highlightCorrectAnswer(int correctIndex) {
        for (int i = 0; i < 4; i++) {
            if (i == correctIndex) {
                optionButtons[i].setBackground(Color.GREEN);
            } else {
                optionButtons[i].setBackground(null);
            }
            optionButtons[i].setEnabled(false);
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(ClientFrame::new);
    }
}
