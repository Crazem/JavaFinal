import java.io.EOFException;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.sql.ResultSet;
import java.sql.SQLException;

public class ClientHandler implements Runnable {
    public Socket socket;
    public ObjectInputStream input;
    public ObjectOutputStream output;
    public String username;
    public String password;

    public boolean hasAnswered = false;
    public int lastAnswerIndex = -1;

    public ClientHandler(Socket socket) {
        this.socket = socket;
        try {
            output = new ObjectOutputStream(socket.getOutputStream());
            output.flush();
            input = new ObjectInputStream(socket.getInputStream());
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void recordAnswer(int selectedIndex) {
        this.lastAnswerIndex = selectedIndex;
        this.hasAnswered = true;
    }

    @Override
    public void run() {
        try {
            // LOGIN / REGISTER
            while (true) {
                output.writeObject("Enter username:");
                output.flush();
                username = (String) input.readObject();

                output.writeObject("Enter password:");
                output.flush();
                password = (String) input.readObject();

                boolean userExists = false;
                try {
                    ResultSet rs = DBConnection.getConnection()
                            .createStatement()
                            .executeQuery("SELECT * FROM users WHERE username='" + username + "'");
                    if (rs.next()) userExists = true;
                } catch (SQLException e) {
                    e.printStackTrace();
                }

                if (!userExists) {
                    try {
                        DBConnection.getConnection()
                                .createStatement()
                                .executeUpdate("INSERT INTO users(username, password, score) VALUES('" +
                                        username + "','" + password + "',0)");
                    } catch (SQLException e) {
                        e.printStackTrace();
                    }
                    output.writeObject("Registered and logged in as " + username + "!");
                    output.flush();
                    break;
                } else {
                    try {
                        ResultSet rs = DBConnection.getConnection()
                                .createStatement()
                                .executeQuery("SELECT password FROM users WHERE username='" + username + "'");
                        if (rs.next() && rs.getString("password").equals(password)) {
                            output.writeObject("Welcome back, " + username + "!");
                            output.flush();
                            break;
                        } else {
                            output.writeObject("Incorrect password, try again.");
                            output.flush();
                        }
                    } catch (SQLException e) {
                        e.printStackTrace();
                    }
                }
            }

            while (true) {
                Object obj = input.readObject();
                if (obj instanceof String) {
                    String answer = (String) obj;
                    if (answer.equals("SKIP")) recordAnswer(-1);
                    else recordAnswer(Integer.parseInt(answer));
                }
            }

        } catch (EOFException eof) {
            System.out.println(username + " disconnected");
        } catch (IOException | ClassNotFoundException e) {
            e.printStackTrace();
        }
    }
}