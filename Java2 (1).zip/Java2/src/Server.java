import javax.swing.*;

public class Server {
    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                ServerFrame frame = new ServerFrame();
                frame.setSize(800, 600);
                frame.setTitle("Trivia Client 2");
                frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                frame.setLocationRelativeTo(null);
                frame.setVisible(true);
            }
        });
    }
}
