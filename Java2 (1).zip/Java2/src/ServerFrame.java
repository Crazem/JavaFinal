import javax.swing.*;
import java.awt.*;
import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.*;
import java.util.List;
import java.util.concurrent.*;
import javax.swing.Timer;

public class ServerFrame extends JFrame {

    private JButton nextButton;
    private JButton startButton;

    private CardLayout cardLayout;
    private JPanel cardPanel;

    private JLabel questionLabel;
    private JButton[] optionButtons = new JButton[4];
    private JLabel feedbackLabel;
    private JLabel timerLabel;

    private int currentQuestionIdx;
    private int timeLeft;
    private Timer countdownTimer;

    private ExecutorService clientExecutor = Executors.newCachedThreadPool();

    private ServerSocket serverSocket;
    private final int PORT = 8081;

    public static List<Question> questions = new ArrayList<>();
    public static List<ClientHandler> clients = new ArrayList<>();

    private UserCRUD userCRUD;

    public ServerFrame() {
        setTitle("Trivia Server");
        setSize(600, 400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        try {
            userCRUD = new UserCRUD(DBConnection.getConnection());
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Database connection failed!");
            System.exit(1);
        }

        cardLayout = new CardLayout();
        cardPanel = new JPanel(cardLayout);

        createLoadingPanel();
        createGamePanel();
        createResultsPanel();

        add(cardPanel);

        currentQuestionIdx = 0;
        cardLayout.show(cardPanel, "L"); // start on loading panel

        // Sample questions
        loadSampleQuestions();

        // Start server socket
        startServer();

        setVisible(true);
    }

    private void createLoadingPanel() {
        JPanel loadingPanel = new JPanel(new BorderLayout());
        JLabel loadingLabel = new JLabel("Trivia Game Server", SwingConstants.CENTER);
        loadingLabel.setFont(new Font("Arial", Font.BOLD, 24));
        loadingPanel.add(loadingLabel, BorderLayout.CENTER);

        startButton = new JButton("Start Game");
        loadingPanel.add(startButton, BorderLayout.SOUTH);

        startButton.addActionListener(e -> {
            currentQuestionIdx = 0;
            broadcastNextQuestion();
            cardLayout.show(cardPanel, "G");
        });

        cardPanel.add(loadingPanel, "L");
    }

    private void createGamePanel() {
        JPanel gamePanel = new JPanel(new BorderLayout());

        JPanel topPanel = new JPanel(new BorderLayout());
        questionLabel = new JLabel("Question placeholder", SwingConstants.CENTER);
        questionLabel.setFont(new Font("Arial", Font.BOLD, 18));

        timerLabel = new JLabel("Time: 10s", SwingConstants.RIGHT);
        timerLabel.setFont(new Font("Arial", Font.BOLD, 16));

        topPanel.add(questionLabel, BorderLayout.CENTER);
        topPanel.add(timerLabel, BorderLayout.EAST);
        gamePanel.add(topPanel, BorderLayout.NORTH);

        feedbackLabel = new JLabel("", SwingConstants.CENTER);
        feedbackLabel.setFont(new Font("Arial", Font.BOLD, 16));
        gamePanel.add(feedbackLabel, BorderLayout.SOUTH);

        nextButton = new JButton("Skip");
        nextButton.addActionListener(e -> skipQuestion());
        gamePanel.add(nextButton, BorderLayout.SOUTH);

        JPanel optionPanel = new JPanel(new GridLayout(2, 2, 10, 10));
        for (int i = 0; i < 4; i++) {
            int index = i;
            optionButtons[i] = new JButton("Option " + (i + 1));
            optionButtons[i].addActionListener(e -> {
                // Mark answer for all clients who haven't answered yet
                for (ClientHandler client : clients) {
                    if (!client.hasAnswered) client.recordAnswer(index);
                }
                for (JButton btn : optionButtons) btn.setEnabled(false);
            });
            optionPanel.add(optionButtons[i]);
        }
        gamePanel.add(optionPanel, BorderLayout.CENTER);

        cardPanel.add(gamePanel, "G");
    }

    private void createResultsPanel() {
        JPanel resultsPanel = new JPanel(new BorderLayout());
        resultsPanel.add(new JLabel("Results", SwingConstants.CENTER), BorderLayout.NORTH);
        cardPanel.add(resultsPanel, "R");
    }

    private void loadSampleQuestions() {
        questions.add(new Question("Capital of France?", new String[]{"Paris", "London", "Berlin", "Rome"}, 0));
        questions.add(new Question("5 + 7 = ?", new String[]{"10", "11", "12", "13"}, 2));
        questions.add(new Question("Sun rises from?", new String[]{"North", "East", "West", "South"}, 1));
    }

    private void startServer() {
        clientExecutor.execute(() -> {
            try {
                serverSocket = new ServerSocket(PORT);
                System.out.println("Server started on port " + PORT);

                while (true) {
                    Socket socket = serverSocket.accept();
                    ClientHandler handler = new ClientHandler(socket);
                    clients.add(handler);
                    clientExecutor.execute(handler);
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        });
    }

    private void broadcastNextQuestion() {
        if (currentQuestionIdx >= questions.size()) {
            showLeaderboard();
            return;
        }

        Question q = questions.get(currentQuestionIdx);

        questionLabel.setText(q.getQuestion());
        for (int i = 0; i < 4; i++) {
            optionButtons[i].setText(q.getOptions()[i]);
            optionButtons[i].setBackground(null); // RESET COLOR
            optionButtons[i].setEnabled(true);    // ENABLE BUTTONS
        }

        feedbackLabel.setText("");

        // Reset clients
        for (ClientHandler client : clients) {
            client.hasAnswered = false;
            client.lastAnswerIndex = -1;
        }

        // Send question to all clients
        for (ClientHandler client : clients) {
            try {
                client.output.writeObject(q);
                client.output.flush();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

        startTimerForAnswers();
    }


    private void startTimerForAnswers() {
        if (countdownTimer != null && countdownTimer.isRunning()) countdownTimer.stop();
        timeLeft = 10;
        timerLabel.setText("Time: " + timeLeft + "s");

        countdownTimer = new Timer(1000, e -> {
            timeLeft--;
            timerLabel.setText("Time: " + timeLeft + "s");

            boolean allAnswered = clients.stream().allMatch(c -> c.hasAnswered);
            if (allAnswered || timeLeft <= 0) {
                countdownTimer.stop();
                validateAllAnswers();
            }
        });
        countdownTimer.start();
    }

    private void validateAllAnswers() {
        countdownTimer.stop();

        Question q = questions.get(currentQuestionIdx);

        boolean[] selectedByClient = new boolean[4];
        for (ClientHandler client : clients) {
            if (client.lastAnswerIndex >= 0 && client.lastAnswerIndex < 4) {
                selectedByClient[client.lastAnswerIndex] = true;
            }
        }

        for (ClientHandler client : clients) {
            boolean correct = client.lastAnswerIndex == q.getCorrectIndex();
            if (correct) {
                userCRUD.updateScore(client.username, userCRUD.getScore(client.username) + 1);
            }

            try {
                if (client.lastAnswerIndex == -1) {
                    client.output.writeObject("SKIP!");
                } else if (correct) {
                    client.output.writeObject("Correct!");
                } else {
                    client.output.writeObject("Wrong!");
                }
                client.output.flush();

                client.output.writeObject(q.getCorrectIndex());
                client.output.flush();

                client.output.flush();
            } catch (IOException ex) {
                ex.printStackTrace();
            }
        }

        for (int i = 0; i < 4; i++) {
            if (i == q.getCorrectIndex()) {
                optionButtons[i].setBackground(Color.GREEN);
            } else {
                optionButtons[i].setBackground(Color.RED);
            }
            optionButtons[i].setEnabled(false);
        }

        new Timer(1000, e -> {
            currentQuestionIdx++;
            ((Timer) e.getSource()).stop();
            broadcastNextQuestion();
        }).start();
    }



    private void skipQuestion() {
        for (ClientHandler client : clients) {
            if (!client.hasAnswered) client.recordAnswer(-1);
        }
        validateAllAnswers();
    }

    private void showLeaderboard() {
        JPanel resultsPanel = new JPanel(new BorderLayout());
        JLabel title = new JLabel("Leaderboard", SwingConstants.CENTER);
        title.setFont(new Font("Arial", Font.BOLD, 20));
        resultsPanel.add(title, BorderLayout.NORTH);

        JTextArea leaderboardArea = new JTextArea();
        leaderboardArea.setEditable(false);

        try {
            ResultSet rs = userCRUD.getTopScores(10);
            while (rs != null && rs.next()) {
                leaderboardArea.append(rs.getString("username") + ": " + rs.getInt("score") + "\n");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        resultsPanel.add(leaderboardArea, BorderLayout.CENTER);
        cardPanel.add(resultsPanel, "R");
        cardLayout.show(cardPanel, "R");
    }
}
