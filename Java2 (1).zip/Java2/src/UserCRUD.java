import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class UserCRUD {
    Connection connection;

    public UserCRUD(Connection connection) {
        this.connection = connection;
    }

    //READ
    public void listUsers() {
        try {
            String sql = "SELECT * FROM users";

            Statement stmt = connection.createStatement();
            ResultSet rs =stmt.executeQuery(sql);

            while (rs.next()) {
                System.out.println(rs.getInt("id")
                        + " | "
                        + rs.getString("username"));
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void addUser(String username) {
        String sql = "INSERT INTO users(username, password) VALUES(?, ?)";
        try {
            PreparedStatement pstmt = connection.prepareStatement(sql);
            pstmt.setString(1, username);
            pstmt.setString(2, "");
            pstmt.executeUpdate();
            System.out.println("User added: " + username);
        } catch (SQLException e) {
            System.out.println("Error adding user: " + username);
            e.printStackTrace();
        }
    }

    // Update user's score
    public void updateScore(String username, int score) {
        String sql = "UPDATE users SET score = ? WHERE username = ?";
        try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
            pstmt.setInt(1, score);
            pstmt.setString(2, username);
            pstmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Get top N scores
    public ResultSet getTopScores(int limit) {
        String sql = "SELECT username, score FROM users ORDER BY score DESC LIMIT ?";
        try {
            PreparedStatement pstmt = connection.prepareStatement(sql);
            pstmt.setInt(1, limit);
            return pstmt.executeQuery();
        } catch (SQLException e) {
            e.printStackTrace();
            return null;
        }
    }

    public int getScore(String username) {
        String sql = "SELECT score FROM users WHERE username = ?";
        try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
            pstmt.setString(1, username);
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) return rs.getInt("score");
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return 0;
    }


}
